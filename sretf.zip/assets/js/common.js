// Common JavaScript functionality for SRE Helper Tool

// Copy to clipboard with visual feedback and fallback for Windows compatibility
function copyToClipboard(text, button) {
  if (!text || text.includes('Please') || text.includes('No valid')) {
    return;
  }
  
  // Function to show success feedback
  const showSuccess = () => {
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-check"></i>Copied!';
    button.style.background = '#2a2a2a';
    button.style.color = '#ffffff';
    setTimeout(() => {
      button.innerHTML = originalText;
      button.style.background = '';
      button.style.color = '';
    }, 2000);
  };
  
  // Fallback method using execCommand (works better on some Windows systems)
  const fallbackCopy = () => {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      if (successful) {
        showSuccess();
        return true;
      }
      return false;
    } catch (err) {
      document.body.removeChild(textArea);
      return false;
    }
  };
  
  // Try modern clipboard API first
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text)
      .then(() => {
        showSuccess();
      })
      .catch(() => {
        // If modern API fails, try fallback method
        if (!fallbackCopy()) {
          alert('Failed to copy to clipboard');
        }
      });
  } else {
    // If clipboard API not available, use fallback
    if (!fallbackCopy()) {
      alert('Failed to copy to clipboard');
    }
  }
}

// Show success animation
function showSuccessAnimation(element) {
  element.style.transform = 'scale(1.02)';
  setTimeout(() => element.style.transform = 'scale(1)', 200);
}

// Format datetime for input fields
function formatDateTimeForInput(date) {
  const pad = n => n.toString().padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

// Initialize default time values (10 minutes ago to now)
function initializeTimeInputs(startId, endId) {
  const now = new Date();
  const tenMinutesAgo = new Date(now - 10 * 60000);
  
  const startElement = document.getElementById(startId);
  const endElement = document.getElementById(endId);
  
  if (startElement) startElement.value = formatDateTimeForInput(tenMinutesAgo);
  if (endElement) endElement.value = formatDateTimeForInput(now);
}

// Validate required fields
function validateFields(fields) {
  for (const field of fields) {
    const element = document.getElementById(field.id);
    if (!element || !element.value.trim()) {
      return { valid: false, message: field.message || `Please fill ${field.id}` };
    }
  }
  return { valid: true };
}

// Show error message
function showError(element, message) {
  element.textContent = message;
  element.style.color = '#ff6b6b';
}

// Show success message
function showSuccess(element, content) {
  element.textContent = content;
  element.style.color = '#ffffff';
  showSuccessAnimation(element);
}

// Replace Font Awesome <i> with inline SVG use
(function replaceIconsWithSVG(){
  const map = {
    'fa-link':'link', 'fa-chart-line':'chart-line', 'fa-map':'map', 'fa-id-card':'id-card',
    'fa-play':'play', 'fa-copy':'copy', 'fa-search':'search', 'fa-sync':'sync', 'fa-plus':'plus',
    'fa-download':'download', 'fa-wrench':'wrench', 'fa-arrow-left':'arrow-left', 'fa-check':'check-circle', 'fa-exclamation-circle':'exclamation-circle'
  };
  document.querySelectorAll('i.fas').forEach(el => {
    const cls = Array.from(el.classList).find(c => c.startsWith('fa-') && c !== 'fas');
    const id = map[cls];
    if(id){
      const span = document.createElement('span');
      span.setAttribute('aria-hidden','true');
      span.style.display='inline-flex'; span.style.width='14px'; span.style.height='14px'; span.style.alignItems='center'; span.style.justifyContent='center';
      span.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24"><use href="assets/icons.svg#${id}"></use></svg>`;
      el.replaceWith(span);
    }
  });
  // Navbar logo: prepend svg if not present
  document.querySelectorAll('.nav-logo').forEach(a => {
    if(!a.querySelector('use')){
      const icon = document.createElement('span');
      icon.className='nav-logo-icon';
      icon.style.display='inline-flex'; icon.style.width='1.1rem'; icon.style.height='1.1rem'; icon.style.alignItems='center'; icon.style.justifyContent='center';
      icon.innerHTML = `<svg viewBox="0 0 24 24" width="100%" height="100%"><use href="assets/icons.svg#project-diagram"></use></svg>`;
      a.prepend(icon);
      a.insertBefore(document.createTextNode(' '), icon.nextSibling);
    }
  });
})();

// Cool gradient background with floating elements
(function initBackgroundEffect() {
  // Create subtle floating orbs - more orbs, smaller size
  const orbCount = 24;
  
  for (let i = 0; i < orbCount; i++) {
    const orb = document.createElement('div');
    const size = Math.random() * 100 + 75;
    const duration = Math.random() * 8 + 6;
    const startX = Math.random() * 100;
    const startY = Math.random() * 100;
    // Use negative delay to start animation partway through the cycle immediately
    const delay = -(Math.random() * duration);
    
    orb.style.cssText = `
      position: fixed;
      width: ${size}px;
      height: ${size}px;
      border-radius: 50%;
      background: radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.12), rgba(255, 255, 255, 0.03));
      pointer-events: none;
      z-index: -1;
      filter: blur(50px);
      left: ${startX}%;
      top: ${startY}%;
      animation: float ${duration}s ease-in-out infinite;
      animation-delay: ${delay}s;
      opacity: 0.7;
    `;
    
    document.body.appendChild(orb);
  }
  
  // Add float animation dynamically
  const style = document.createElement('style');
  style.textContent = `
    @keyframes float {
      0%, 100% {
        transform: translate(0, 0) scale(1);
        opacity: 0.7;
      }
      25% {
        transform: translate(120px, -120px) scale(1.2);
        opacity: 0.9;
      }
      50% {
        transform: translate(-80px, 160px) scale(0.8);
        opacity: 0.6;
      }
      75% {
        transform: translate(160px, 80px) scale(1.15);
        opacity: 0.85;
      }
    }
  `;
  document.head.appendChild(style);
})();

// Fix footer alignment on Windows (account for scrollbar width)
(function fixFooterScrollbarAlignment() {
  function updateFooterPadding() {
    const footer = document.querySelector('.footer');
    if (!footer) return;
    
    // Calculate scrollbar width
    const outer = document.createElement('div');
    outer.style.visibility = 'hidden';
    outer.style.overflow = 'scroll';
    outer.style.msOverflowStyle = 'scrollbar'; // needed for WinJS apps
    document.body.appendChild(outer);
    
    const inner = document.createElement('div');
    outer.appendChild(inner);
    
    const scrollbarWidth = outer.offsetWidth - inner.offsetWidth;
    document.body.removeChild(outer);
    
    // Only adjust if scrollbar is visible and takes space (Windows behavior)
    if (scrollbarWidth > 0 && document.documentElement.scrollHeight > document.documentElement.clientHeight) {
      footer.style.paddingRight = `${20 + scrollbarWidth}px`;
    } else {
      footer.style.paddingRight = '20px';
    }
  }
  
  // Update on load and resize
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', updateFooterPadding);
  } else {
    updateFooterPadding();
  }
  
  window.addEventListener('resize', updateFooterPadding);
})();

